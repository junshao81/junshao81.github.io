import argparse
import os 

def get_args():
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--device', type=str, default='cuda', help='cuda, cpu')
    parser.add_argument('--checkpoint_load', type=str, default=None)
    parser.add_argument('--intra_checkpoint_load', type=str, default=None)
    parser.add_argument('--checkpoint_save', type=str, default=None)
    parser.add_argument('--log', type=str, default=None)
    parser.add_argument("--data_root", type=str, default='/home/star/code/Effective_backdoor_defense-main/dataset/')

    parser.add_argument('--dataset', type=str, default='cifar10', help='cifar10, cifar100, imagenet')
    parser.add_argument("--num_classes", type=int, default=None)
    parser.add_argument("--input_height", type=int, default=None)
    parser.add_argument("--input_width", type=int, default=None)
    parser.add_argument("--input_channel", type=int, default=None)

    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument("--num_workers", type=float, default=0)
    parser.add_argument('--lr', type=float, default=0.01)

    parser.add_argument('--poison_rate', type=float, default=0.1) # decides how many training samples are poisoned
    parser.add_argument('--clean_rate', type=float, default=1.0) # decides how many clean training samples are provided in some defense methods
    parser.add_argument('--target_type', type=str, default='all2one', help='all2one, all2all, cleanLabel') 
    parser.add_argument('--target_label', type=int, default=0)
    parser.add_argument('--trigger_type', type=str, default='gridTrigger', help='gridTrigger, squareTrigger, trojanTrigger, signalTrigger, kittyTrigger, sigTrigger, fourCornerTrigger')

    # Others
    parser.add_argument('--model', type=str, default='resnet18')

    parser.add_argument('--gamma_low', type=float, default=None, help='<=gamma_low is clean') # \gamma_c
    parser.add_argument('--gamma_high', type=float, default=None, help='>=gamma_high is poisoned') # \gamma_p
    parser.add_argument('--clean_ratio', type=float, default=0.20, help='ratio of clean data') # \alpha_c
    parser.add_argument('--poison_ratio', type=float, default=0.05, help='ratio of poisoned data') # \alpha_p

    parser.add_argument('--gamma', type=float, default=0.1, help='LR is multiplied by gamma on schedule.')
    parser.add_argument('--schedule', type=int, nargs='+', default=[100, 150], help='Decrease learning rate at these epochs.')
    parser.add_argument('-warm', type=int, default=1, help='warm up training phase')

    parser.add_argument('--trans1', type=str, default='color') # the first data augmentation
    parser.add_argument('--trans2', type=str, default='perspective') # the second data augmentation

    parser.add_argument('--set_poison_ratio', type=float, default=0.5, help='Ratio of poisoned samples in the new training set.')
    parser.add_argument('--use_poison_ratio', type=float, default=1.0, help='Ratio of poisoned dataset utilized for training.')

    parser.add_argument('--second_epoch', type=int, default=100)
    parser.add_argument('--second_confidence', type=float, default=0.9)

    parser.add_argument('--epoch_a', type=int, default=0)
    parser.add_argument('--epoch_b', type=int, default=9)

    arg = parser.parse_args()

    # Set image class and size
    if arg.dataset == "cifar10":
        arg.num_classes = 10
        arg.input_height = 32
        arg.input_width = 32
        arg.input_channel = 3
    elif arg.dataset == "cifar100":
        arg.num_classes = 100
        arg.input_height = 32
        arg.input_width = 32
        arg.input_channel = 3
    elif arg.dataset == "imagenet":
        arg.num_classes = 12
        arg.input_height = 64
        arg.input_width = 64
        arg.input_channel = 3
    elif arg.dataset == "gtsrb":
        arg.num_classes = 43
        arg.input_height = 48
        arg.input_width = 48
        arg.input_channel = 3
    else:
        raise Exception("Invalid Dataset")

    arg.data_root = arg.data_root + arg.dataset    
    if not os.path.isdir(arg.data_root):
        os.makedirs(arg.data_root)
    print(arg)
    return arg
