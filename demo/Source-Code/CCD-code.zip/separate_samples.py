import sys
import os
from tqdm import tqdm
import numpy as np
import csv
from PIL import Image

import torch
from torch import nn
import torchvision
import torchvision.transforms as transforms
import torch.multiprocessing
torch.multiprocessing.set_sharing_strategy('file_system')

from utils import args
from utils.utils import save_checkpoint, progress_bar, normalization
from utils.network import get_network
from utils.dataloader_bd import get_dataloader_train, get_dataloader_test


def separate_samples(arg, trainloader, init_model, intra_model):
    init_model.eval()
    intra_model.eval()
    poisoned_samples_num = 0
    my_test_num=0
    test_poisoned_num =0
    test_poisoned_error_num=0
    test_clean_num = 0
    test_clean_error_num=0
    test_suspicious_num=0
    # 开始划分，之前是计算分离值
    clean_samples, poison_samples, suspicious_samples = [], [], []
    folder_path = os.path.join('./saved/separated_samples', 'poison_rate_'+str(arg.poison_rate), arg.dataset, arg.model,arg.target_type ,arg.trigger_type+'_'+str(arg.clean_ratio)+'_'+str(arg.poison_ratio))
    
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    for i, (inputs, labels, gt_labels, isCleans) in enumerate(trainloader):
        
        if i % 10000 == 0:
            print("Processing samples:", i)
        inputs1 = inputs[0]  #inputs[0] inputs[2]这里有3个组合变换，inputs是一张图片的3个变换（针对trainloader）
        
        ### Prepare for saved ###
        img = inputs1
        img = img.squeeze()
        target = labels.squeeze()
        gt_label = gt_labels.squeeze().cpu().numpy()
        
       
        img = np.transpose((img * 255).cpu().numpy(), (1, 2, 0)).astype('uint8')
        target = target.cpu().numpy()


        inputs1 = normalization(arg, inputs1)  # Normalize
        inputs1, labels, gt_labels = inputs1.to(arg.device),labels.to(arg.device), gt_labels.to(arg.device)
        
        init_output = init_model(inputs1)
        intra_output = intra_model(inputs1)
        init_probabilities = torch.nn.functional.softmax(init_output, dim=1)
        intra_probabilities = torch.nn.functional.softmax(intra_output, dim=1)
       

        init_confidence, init_predicted_label = torch.max(init_probabilities, 1)
        intra_confidence, intra_predicted_label = torch.max(intra_probabilities, 1)
        intra_confidence_init=intra_probabilities[0][init_predicted_label.item()].item()
        # print(gt_label)
        # print(target)
        # print(isCleans)
        if not isCleans.item():
            poisoned_samples_num += 1

        if ((init_predicted_label.item()==intra_predicted_label.item() and init_confidence>0.9 and intra_confidence>0.9) 
            ):
            # or (init_confidence>0.9 and 0.1<intra_confidence<0.2)
            test_poisoned_num +=1
            poison_samples.append((img, target,gt_label,isCleans))

            if isCleans.item():
                test_poisoned_error_num += 1
                
            my_test_num+=1
        elif(init_predicted_label.item()!=intra_predicted_label.item() and 0.1<abs( init_confidence-intra_confidence_init)<0.5):
            test_clean_num += 1
            clean_samples.append((img, target, gt_label,isCleans))
            if not isCleans.item():
                test_clean_error_num += 1

            my_test_num += 1
           
        else:
            test_suspicious_num +=1
            suspicious_samples.append((img, target, gt_label,isCleans))
            my_test_num += 1
        with open(os.path.join(os.path.join('./saved/separated_samples', 'poison_rate_'+str(arg.poison_rate), arg.dataset, arg.model,arg.target_type ,arg.trigger_type+'_'+str(arg.clean_ratio)+'_'+str(arg.poison_ratio)),"seperated_samples.txt"), "a") as file:
            # 遍历数据列表，逐行写入文件
                file.write('target: '+ str(target) +' gt_labels: '+str(gt_labels.item()) +' isCleans: '+str(isCleans)+ "\n") 
                file.write('init_confidence: '+str(init_confidence.item()) + ' init_predicted_label: ' + str(init_predicted_label.item()) + "\n")    
                file.write('intra_confidence: '+ str(intra_confidence.item())+ ' intra_predicted_label: ' + str(intra_predicted_label.item()) + "\n")
                file.write('intra_confidence_init: '+ str(intra_confidence_init) + "\n")

    print('my_teset_num:',my_test_num)
    print('poisoned_samples_num:',poisoned_samples_num)
    print('test_poisoned_num:',test_poisoned_num)
    print('test_clean_num:',test_clean_num)
    print('test_poisoned_error_num:',test_poisoned_error_num)
    print('test_clean_error_num:',test_clean_error_num)
    print('test_suspicious_num',test_suspicious_num)
        

    ### Save samples ###
    folder_path = os.path.join('./saved/separated_samples', 'poison_rate_'+str(arg.poison_rate), arg.dataset, arg.model,arg.target_type ,arg.trigger_type+'_'+str(arg.clean_ratio)+'_'+str(arg.poison_ratio))
    batchsize =  256
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    info_path = os.path.join(folder_path, 'seperate_samples_info.txt')
    with open(info_path, 'w') as file:
        file.write(f"my_teset_num:{my_test_num}\n")
        file.write(f"poisoned_samples_num:{poisoned_samples_num} test_poisoned_num:{test_poisoned_num} test_poisoned_error_num:{test_poisoned_error_num}\n")
        file.write(f"test_clean_num:{test_clean_num} test_clean_error_num:{test_clean_error_num}\n")
        file.write(f"test_suspicious_num:{test_suspicious_num}\n")
    print(f"可疑数据集分割信息已成功保存至 {info_path}")
    data_path_clean = os.path.join(folder_path, 'clean_samples.npy')
    data_path_poison = os.path.join(folder_path, 'poison_samples.npy')
    data_path_suspicious = os.path.join(folder_path, 'suspicious_samples.npy')
    clean_samples = np.asarray(clean_samples,dtype=object)
    poison_samples = np.asarray(poison_samples,dtype=object)
    suspicious_samples = np.asarray(suspicious_samples,dtype=object)
    np.save(data_path_clean, clean_samples)
    np.save(data_path_poison, poison_samples)
    np.save(data_path_suspicious, suspicious_samples)
 

def main():
    global arg
    arg = args.get_args()

    # Dataset
    trainloader = get_dataloader_train(arg)

    # Prepare backdoored model, optimizer, scheduler
    init_model = get_network(arg)
    init_model = torch.nn.DataParallel(init_model).cuda()
    init_checkpoint = torch.load(arg.checkpoint_load)

    intra_model = get_network(arg)
    intra_model = torch.nn.DataParallel(intra_model).cuda()
    intra_checkpoint = torch.load(arg.intra_checkpoint_load)
    print("Continue training...")
    init_model.load_state_dict(init_checkpoint['model'])
    intra_model.load_state_dict(intra_checkpoint['model'])

    separate_samples(arg, trainloader, init_model, intra_model)

if __name__ == '__main__':
    main()
