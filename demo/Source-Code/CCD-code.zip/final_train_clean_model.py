import sys
import os
from tqdm import tqdm
import numpy as np
import csv
from PIL import Image

import torch
from torch import nn
import torchvision
import torchvision.transforms as transforms
import torch.multiprocessing
torch.multiprocessing.set_sharing_strategy('file_system')
from torch.utils.data import Dataset, DataLoader
from utils import args
from utils.utils import save_checkpoint, progress_bar, normalization
from utils.network import get_network
from utils.dataloader_bd import get_dataloader_train, get_dataloader_test
from utils.dataloader_bd import get_dataloader_train, get_dataloader_test, Dataset_npy
def test_epoch(arg, testloader, model, criterion, epoch, word):
    model.eval()

    total_clean = 0
    total_clean_correct, total_robust_correct = 0, 0
    test_loss = 0
    
    for i, (inputs, labels, gt_labels,isCleans) in enumerate(testloader):
        inputs = normalization(arg, inputs)  # Normalize
        inputs, labels ,gt_labels= inputs.to(arg.device), labels.to(arg.device),gt_labels.to(arg.device)
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        
        test_loss += loss.item()
        total_clean_correct += torch.sum(torch.argmax(outputs[:], dim=1) == labels[:])
        total_robust_correct += torch.sum(torch.argmax(outputs[:], dim=1) == gt_labels[:])
        total_clean += inputs.shape[0]
        avg_acc_clean = total_clean_correct * 100.0 / total_clean
        avg_acc_robust = total_robust_correct * 100.0 / total_clean
        if word == 'clean':
            progress_bar(i, len(testloader), 'Epoch: %d | Loss: %.3f | Test %s ACC: %.3f%% (%d/%d)' % (
                epoch, test_loss / (i + 1), word, avg_acc_clean, total_clean_correct, total_clean))
        if word == 'bd':
            progress_bar(i, len(testloader), 'Epoch: %d | Loss: %.3f | ASR: %.3f%% (%d/%d) | R-ACC: %.3f%% (%d/%d)' % (
                epoch, test_loss / (i + 1), avg_acc_clean, total_clean_correct, total_clean, avg_acc_robust,
                total_robust_correct, total_clean))
    return test_loss / (i + 1), avg_acc_clean, avg_acc_robust
def train_epoch(arg, trainloader, model, optimizer, scheduler, criterion, epoch):
    model.train()

    total_clean, total_poison = 0, 0
    total_clean_correct, total_attack_correct, total_robust_correct = 0, 0, 0
    train_loss = 0
    for i, (inputs, labels, isCleans) in enumerate(trainloader):  
        isCleans = isCleans.squeeze()
        inputs = normalization(arg, inputs)  # Normalize
        inputs, labels = inputs.to(arg.device), labels.to(arg.device)
        # if not (0<=labels.item()<=9):
        #     print(labels)
        clean_idx, poison_idx = torch.where(isCleans == True), torch.where(isCleans == False)
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        train_loss += loss.item()
        total_clean_correct += torch.sum(torch.argmax(outputs[:], dim=1) == labels[:])
        total_attack_correct += torch.sum(torch.argmax(outputs[poison_idx], dim=1) == labels[poison_idx])
        total_clean += inputs.shape[0]
        total_poison += inputs[poison_idx].shape[0]
        avg_acc_clean = total_clean_correct * 100.0 / total_clean
        if total_poison == 0:
            avg_acc_attack=0.0
        else:
            avg_acc_attack = total_attack_correct * 100.0 / total_poison
        # progress_bar(i, len(trainloader),
        #              'Epoch: %d | Loss: %.3f | Train ACC: %.3f%% (%d/%d) | Train ASR: %.3f%% (%d/%d)' % (
        #              epoch, train_loss / (i + 1), avg_acc_clean, total_clean_correct, total_clean, avg_acc_attack,
        #              total_attack_correct, total_poison))
    scheduler.step()
    return train_loss / (i + 1), avg_acc_clean, avg_acc_attack
# , avg_acc_robust

def train_new_model(arg,first_data_path_clean, second_data_path_clean):
    # 加载.npy数据集文件
    first_data_clean = np.load(first_data_path_clean,allow_pickle=True)

    # 构建新的数据集
    second_clean_dataset = np.load(second_data_path_clean,allow_pickle=True)

    # 打印新数据集的长度和目标的长度
    final_clean_dataset = np.concatenate((first_data_clean, second_clean_dataset), axis=0)
    # print(final_clean_dataset.shape)
    print("新数据集长度:", len(final_clean_dataset))

    transforms_list=[]
    transforms_list.append(transforms.ToPILImage())
    transforms_list.append(transforms.Resize((arg.input_height, arg.input_width)))
    transforms_list.append(transforms.RandomCrop((arg.input_height, arg.input_width), padding=4))
    transforms_list.append(transforms.RandomRotation(20))
    transforms_list.append(transforms.RandomHorizontalFlip(0.5))
    transforms_list.append(transforms.ToTensor())

    tf_compose_finetuning = transforms.Compose(transforms_list)
    
    new_data_tf = Dataset_npy(full_dataset=final_clean_dataset,transform=tf_compose_finetuning)
    new_data_loader = DataLoader(dataset=new_data_tf, batch_size=arg.batch_size, shuffle=True)
    testloader_clean, testloader_bd = get_dataloader_test(arg)
    
    # # Prepare model, optimizer, scheduler
    model = get_network(arg)
    model = torch.nn.DataParallel(model).cuda()

    optimizer = torch.optim.SGD(model.parameters(), lr=arg.lr, momentum=0.9, weight_decay=5e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200)

    print("Training from scratch...")
    start_epoch = 0

    # Training and Testing
    best_acc = 0
    criterion = nn.CrossEntropyLoss()

    # Write
    save_folder_path = os.path.join('./saved/final_clean_model', 'poison_rate_'+str(arg.poison_rate), arg.dataset, arg.model, arg.trigger_type,arg.target_type)
    if not os.path.exists(save_folder_path):
        os.makedirs(save_folder_path)
    arg.log = os.path.join(save_folder_path, 'result.csv')
    f_name = arg.log
    csvFile = open(f_name, 'a', newline='')
    writer = csv.writer(csvFile)
    writer.writerow(
        ['Epoch', 'Train_Loss', 'Train_ACC', 'Train_ASR', 'Test_Loss_cl', 'Test_ACC', 'Test_Loss_bd',
         'Test_ASR', 'Test_R-ACC'])

    for epoch in tqdm(range(start_epoch, arg.epochs)):
        train_loss, train_acc, train_asr = train_epoch(arg, new_data_loader, model, optimizer, scheduler, criterion, epoch)
        test_loss_cl, test_acc_cl, _ = test_epoch(arg, testloader_clean, model, criterion, epoch, 'clean')
        test_loss_bd, test_acc_bd, test_acc_robust = test_epoch(arg, testloader_bd, model, criterion, epoch, 'bd')

        # Save in every epoch
        save_file_path = os.path.join(save_folder_path, 'best_clean_acc.tar')
        if test_acc_bd > best_acc:
            best_acc = test_acc_bd
            save_checkpoint(save_file_path, epoch, model, optimizer, scheduler)

        writer.writerow(
            [epoch, train_loss, train_acc.item(), train_asr, test_loss_cl, test_acc_cl.item()
            ,test_loss_bd, test_acc_bd.item(), test_acc_robust.item()
             ])
    csvFile.close()



def main():
    global arg
    arg = args.get_args()

    # Dataset
    # trainloader = get_dataloader_train(arg)

    # Prepare clean_samples,suscipious_samples,poison_samples
    folder_path = os.path.join('./saved/separated_samples', 'poison_rate_'+str(arg.poison_rate), arg.dataset, arg.model,arg.target_type ,arg.trigger_type+'_'+str(arg.clean_ratio)+'_'+str(arg.poison_ratio),'epoch_'+str(arg.second_epoch)+'_'+str(arg.second_confidence)) 
    first_data_path_clean = os.path.join(folder_path, 'second_clean_samples.npy')
    second_data_path_clean = os.path.join(folder_path, 'second_clean_samples.npy')
    
    print("Continue separate samples...")
    
    train_new_model(arg, first_data_path_clean,second_data_path_clean)

if __name__ == '__main__':
    main()