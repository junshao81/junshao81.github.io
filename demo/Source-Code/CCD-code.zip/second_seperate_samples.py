import sys
import os
from tqdm import tqdm
import numpy as np
import csv
from PIL import Image

import torch
from torch import nn
import torchvision
import torchvision.transforms as transforms
import torch.multiprocessing
torch.multiprocessing.set_sharing_strategy('file_system')
from torch.utils.data import Dataset, DataLoader
from utils import args
from utils.utils import save_checkpoint, progress_bar, normalization
from utils.network import get_network
from utils.dataloader_bd import get_dataloader_train, get_dataloader_test
from utils.dataloader_bd import get_dataloader_train, get_dataloader_test, Dataset_npy

def seperate_clean_samples(arg, data_path_clean,model):
    test_poisoned_num,test_clean_num,clean_num,poisoned_num = 0,0,0,0
    model.eval()
    clean_samples, poison_samples = [], []
    data_clean = np.load(data_path_clean,allow_pickle=True)
    img_clean, target_clean, gtlabel_clean, isClean_clean = data_clean[:, :4].T
    data_suspicious = np.column_stack((img_clean, target_clean, isClean_clean))
    transforms_list=[]
    transforms_list.append(transforms.ToPILImage())
    transforms_list.append(transforms.Resize((arg.input_height, arg.input_width)))
    transforms_list.append(transforms.ToTensor())
    tf_compose_finetuning = transforms.Compose(transforms_list)
    
    new_data_tf = Dataset_npy(full_dataset=data_suspicious,transform=tf_compose_finetuning)
    new_data_loader = DataLoader(dataset=new_data_tf, batch_size=arg.batch_size, shuffle=True)
    print(len(new_data_loader))
    for i, (inputs, labels, isCleans) in enumerate(new_data_loader):
        isCleans = isCleans.squeeze(0)
        # print(isCleans.shape)
        if i % 10000 == 0:
            print("Processing samples:", i)

        target = labels.squeeze()
        target = target.cpu().numpy()
        img = inputs
        img = img.squeeze()
        img = np.transpose((img * 255).cpu().numpy(), (1, 2, 0)).astype('uint8')
        inputs = normalization(arg, inputs)  # Normalize
        inputs, labels = inputs.to(arg.device),labels.to(arg.device)
        
        output = model(inputs)
        probabilities = torch.nn.functional.softmax(output, dim=1)
        confidence, predicted_label = torch.max(probabilities, 1)
        if(predicted_label.item()==0 and confidence>arg.second_confidence):
        # if(confidence>0.9):
            test_poisoned_num += 1
            poison_samples.append((img, target,isCleans))
            if not isCleans.item():
                poisoned_num += 1
        else:
            test_clean_num += 1
            clean_samples.append((img, target,isCleans))
            if isCleans.item():
                clean_num+=1
            else:
                print(confidence,predicted_label)
    print('test_poisoned_num:',test_poisoned_num,' test_clean_num:',test_clean_num,' clean_num:',clean_num,' poisoned_num:',poisoned_num)
    folder_path = os.path.join('./saved/separated_samples', 'poison_rate_'+str(arg.poison_rate), arg.dataset, arg.model,arg.target_type ,arg.trigger_type+'_'+str(arg.clean_ratio)+'_'+str(arg.poison_ratio),'epoch_'+str(arg.second_epoch)+'_'+str(arg.second_confidence))
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    info_path = os.path.join(folder_path, 'seperate_clean_samples_info'+str(arg.second_epoch)+'epoch_'+str(arg.second_confidence)+'.txt')
    isClean_clean = np.array(isClean_clean, dtype=object)
    isClean_values = np.array([item.item() for item in isClean_clean])
    with open(info_path, 'w') as file:
        file.write(f"test_poisoned_num:{test_poisoned_num} test_clean_num:{test_clean_num} clean_num:{clean_num} poisoned_num:{poisoned_num}\n")
        file.write(f"isClean_num:{len(isClean_clean)} Clean_num:{np.sum(isClean_values)}  Posion_num:{len(isClean_values) - np.sum(isClean_values)}\n")
    print(f"干净数据集分割信息已成功保存至 {info_path}")

    data_path_clean = os.path.join(folder_path, 'second_clean_samples_clean_'+str(arg.second_epoch)+'epoch_'+str(arg.second_confidence)+'.npy')
    data_path_poison = os.path.join(folder_path, 'second_poison_samples_clean_'+str(arg.second_epoch)+'epoch_'+str(arg.second_confidence)+'.npy')
    clean_samples = np.asarray(clean_samples,dtype=object)
    poison_samples = np.asarray(poison_samples,dtype=object)
    np.save(data_path_clean, clean_samples)
    np.save(data_path_poison, poison_samples)

def seperate_samples(arg, data_path_suspicious,model):
    test_poisoned_num,test_clean_num,clean_num,poisoned_num = 0,0,0,0
    model.eval()
    clean_samples, poison_samples = [], []
    data_suspicious = np.load(data_path_suspicious,allow_pickle=True)
    img_suspicious, target_suspicious, gtlabel_suspicious, isClean_suspicious = data_suspicious[:, :4].T
    data_suspicious = np.column_stack((img_suspicious, target_suspicious, isClean_suspicious))
    transforms_list=[]
    transforms_list.append(transforms.ToPILImage())
    transforms_list.append(transforms.Resize((arg.input_height, arg.input_width)))
    transforms_list.append(transforms.ToTensor())
    tf_compose_finetuning = transforms.Compose(transforms_list)
    
    new_data_tf = Dataset_npy(full_dataset=data_suspicious,transform=tf_compose_finetuning)
    new_data_loader = DataLoader(dataset=new_data_tf, batch_size=arg.batch_size, shuffle=True)
    print(len(new_data_loader))
    for i, (inputs, labels, isCleans) in enumerate(new_data_loader):
        isCleans = isCleans.squeeze(0)
        # print(isCleans.shape)
        if i % 10000 == 0:
            print("Processing samples:", i)
        
        ### Prepare for saved ###
        target = labels.squeeze()
        # gt_label = gt_labels.squeeze().cpu().numpy()
        target = target.cpu().numpy()
        img = inputs
        img = img.squeeze()
        img = np.transpose((img * 255).cpu().numpy(), (1, 2, 0)).astype('uint8')
        inputs = normalization(arg, inputs)  # Normalize
        inputs, labels = inputs.to(arg.device),labels.to(arg.device)
        
        output = model(inputs)
        probabilities = torch.nn.functional.softmax(output, dim=1)

        confidence, predicted_label = torch.max(probabilities, 1)
        if(predicted_label.item()==0 and confidence>arg.second_confidence):

            test_poisoned_num += 1
            poison_samples.append((img, target,isCleans))
            if not isCleans.item():
                poisoned_num += 1
        else:
            test_clean_num += 1
            clean_samples.append((img, target,isCleans))
            if isCleans.item():
                clean_num+=1
            else:
                print(predicted_label,confidence)
    print('test_poisoned_num:',test_poisoned_num,' test_clean_num:',test_clean_num,' clean_num:',clean_num,' poisoned_num:',poisoned_num)
    folder_path = os.path.join('./saved/separated_samples', 'poison_rate_'+str(arg.poison_rate), arg.dataset, arg.model,arg.target_type ,arg.trigger_type+'_'+str(arg.clean_ratio)+'_'+str(arg.poison_ratio),'epoch_'+str(arg.second_epoch)+'_'+str(arg.second_confidence))
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    info_path = os.path.join(folder_path, 'seperate_samples_info_'+str(arg.second_epoch)+'epoch_'+str(arg.second_confidence)+'.txt')
    isClean_values = np.array([item.item() for item in isClean_suspicious])
    with open(info_path, 'w') as file:
        file.write(f"test_poisoned_num:{test_poisoned_num} test_clean_num:{test_clean_num} clean_num:{clean_num} poisoned_num:{poisoned_num}\n")
        file.write(f"isClean_num:{len(isClean_suspicious)} Clean_num:{np.sum(isClean_values)}  Posion_num:{len(isClean_values) - np.sum(isClean_values)}\n")
    print(f"可疑数据集分割信息已成功保存至 {info_path}")

    data_path_clean = os.path.join(folder_path, 'second_clean_samples.npy')
    data_path_poison = os.path.join(folder_path, 'second_poison_samples.npy')
    clean_samples = np.asarray(clean_samples,dtype=object)
    poison_samples = np.asarray(poison_samples,dtype=object)
    np.save(data_path_clean, clean_samples)
    np.save(data_path_poison, poison_samples)
    
def main():
    global arg
    arg = args.get_args()

    epoch_a, epoch_b, batchsize = 0, 14, 256

    # Prepare clean_samples,suscipious_samples,poison_samples
    folder_path = os.path.join('./saved/separated_samples', 'poison_rate_'+str(arg.poison_rate), arg.dataset, arg.model,arg.target_type ,arg.trigger_type+'_'+str(arg.clean_ratio)+'_'+str(arg.poison_ratio))
    data_path_suspicious = os.path.join(folder_path, f'suspicious_samples.npy')
    data_path_clean = os.path.join(folder_path, f'clean_samples.npy')
    print("Continue separate samples...")
    

    new_model = get_network(arg)
    new_model = torch.nn.DataParallel(new_model).cuda()
    new_checkpoint = torch.load(arg.checkpoint_load)
    new_model.load_state_dict(new_checkpoint['model'])
    seperate_clean_samples(arg, data_path_clean,new_model)
    seperate_samples(arg, data_path_suspicious,new_model)

if __name__ == '__main__':
    main()