# Cracking the Code of Backdoor Attacks with Confidence Consistency
The official implementation of the paper "Cracking the Code of Backdoor Attacks with Confidence Consistency"

<img src="./plot/core.pdf" width="80%" height="80%">

## Environment
This code is implemented in PyTorch, and we have tested the code under the following environment settings:
- python = 3.8.0
- torch = 1.11.0+cu113
- torchvision = 0.12.0+cu113

## Run

```
python train_attack.py --dataset cifar10 --model resnet18 --trigger_type gridTrigger --epochs 2 --poison_rate 0.1 

python finetune_attack.py --dataset cifar10 --model resnet18 --trigger_type gridTrigger --epochs 10 \
	--checkpoint_load ./saved/backdoored_model/poison_rate_0.1/noTrans/cifar10/resnet18/gridTrigger/all2one/1.tar \
	--poison_rate 0.1 --batch_size 256 --lr 0.1

python separate_samples.py --dataset cifar10 --model resnet18 --trigger_type gridTrigger --batch_size 1  \
 --checkpoint_load ./saved/backdoored_model/poison_rate_0.1/noTrans/cifar10/resnet18/gridTrigger/all2one/1.tar \
 --intra_checkpoint_load ./saved/backdoored_model/poison_rate_0.1/noTrans_ftsimi/cifar10/resnet18/gridTrigger/all2one/256/9_1.tar \
 --target_type all2one --poison_rate 0.1 --epoch_a 1 --epoch_b 9

python second_train.py --dataset cifar10 --model resnet18 --trigger_type gridTrigger --target_type all2one --poison_rate 0.1  --epochs 20 --batch_size 256

python second_seperate_samples.py --dataset cifar10 --model resnet18 --trigger_type gridTrigger --target_type all2one --poison_rate 0.1 --epochs 20 --batch_size 1 \
--checkpoint_load ./saved/second_model/poison_rate_0.1/cifar10/resnet18/gridTrigger/all2one/19.tar

python final_train_clean_model.py --dataset cifar10 --model resnet18 --trigger_type gridTrigger --epochs 200 --poison_rate 0.1 --lr 0.1 --batch_size 256

```